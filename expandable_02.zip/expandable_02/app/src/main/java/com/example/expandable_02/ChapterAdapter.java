package com.example.expandable_02;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.thoughtbot.expandablerecyclerview.ExpandableRecyclerViewAdapter;
import com.thoughtbot.expandablerecyclerview.models.ExpandableGroup;

import java.util.List;

public class ChapterAdapter extends ExpandableRecyclerViewAdapter<BookViewHolder , ChapterViewHolder> {
    public ChapterAdapter(List<? extends ExpandableGroup> groups) {
        super(groups);
    }

    @Override
    public BookViewHolder onCreateGroupViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.expandable_recyclerview_book, parent, false);
        return new BookViewHolder(v);
    }

    @Override
    public ChapterViewHolder onCreateChildViewHolder(ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.expandable_recyclerview_chapter, parent, false);
        return new ChapterViewHolder(v);
    }

    @Override
    public void onBindChildViewHolder(ChapterViewHolder holder, int flatPosition, ExpandableGroup group, int childIndex) {
        final Chapter chapter= (Chapter) group.getItems().get(childIndex);
        holder.bind(chapter);
    }

    @Override
    public void onBindGroupViewHolder(BookViewHolder holder, int flatPosition, ExpandableGroup group) {
        final Book book = (Book) group;
        holder.bind(book);
    }
}
