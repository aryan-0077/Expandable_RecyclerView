package com.example.expandable_02;

import android.os.Parcel;
import android.os.Parcelable;

public class Chapter implements Parcelable {

    public final String name;

    public Chapter(String name) {
        this.name = name;
    }

    protected Chapter(Parcel in) {
        name = in.readString();
    }

    public static final Creator<Chapter> CREATOR = new Creator<Chapter>() {
        @Override
        public Chapter createFromParcel(Parcel in) {
            return new Chapter(in);
        }

        @Override
        public Chapter[] newArray(int size) {
            return new Chapter[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
    }
}
