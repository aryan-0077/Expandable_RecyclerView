package com.example.expandable_02;

import android.view.View;
import android.widget.TextView;

import com.thoughtbot.expandablerecyclerview.viewholders.ChildViewHolder;

public class ChapterViewHolder extends ChildViewHolder {

    private TextView mTextView;

    public ChapterViewHolder(View itemView) {
        super(itemView);
        mTextView = itemView.findViewById(R.id.textView);
    }

    public void bind(Chapter chapter){
        mTextView.setText(chapter.name);
    }
}
