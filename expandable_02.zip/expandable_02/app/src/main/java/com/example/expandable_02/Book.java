package com.example.expandable_02;

import com.thoughtbot.expandablerecyclerview.models.ExpandableGroup;

import java.util.List;

public class Book extends ExpandableGroup<Chapter> {
    public Book(String title, List<Chapter> items) {
        super(title, items);
    }
}
