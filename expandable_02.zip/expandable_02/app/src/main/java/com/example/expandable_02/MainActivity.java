package com.example.expandable_02;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initializing Recycler View in Main Activity
        RecyclerView recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        ArrayList<Book> books = new ArrayList<>();


        ArrayList<Chapter> insight_book = new ArrayList<>();
        insight_book.add(new Chapter("The Shortlist "));
        insight_book.add(new Chapter("Buddy Process & Company Interaction/Dinner "));
        insight_book.add(new Chapter("Final Interview "));

        Book insight = new Book("Insight into the process",insight_book);
        books.add(insight);

        ArrayList<Chapter> caseinterview_book = new ArrayList<>();
        caseinterview_book.add(new Chapter("Pre-Case Conversation"));
        caseinterview_book.add(new Chapter("Case Introduced"));
        caseinterview_book.add(new Chapter("Understanding of the Client situation"));
        caseinterview_book.add(new Chapter("Deep dive into case for diagnosis"));
        caseinterview_book.add(new Chapter("Potential Solutions/Summary "));

        Book caseinterview = new Book("Structure of Case Interview ",caseinterview_book);
        books.add(caseinterview);

        ArrayList<Chapter> firms_book = new ArrayList<>();
        firms_book.add(new Chapter("Accenture Strategy "));
        firms_book.add(new Chapter("A.T. Kearney "));
        firms_book.add(new Chapter("Brain & Co. "));
        firms_book.add(new Chapter("The Boston Consulting Group "));
        firms_book.add(new Chapter("Deloitte "));
        firms_book.add(new Chapter("MasterCard Advisors "));
        firms_book.add(new Chapter("McKinsey and Company "));

        Book firm = new Book("Major Consulting firms ",firms_book);
        books.add(firm);



        ChapterAdapter adapter = new ChapterAdapter(books);
        recyclerView.setAdapter(adapter);
    }
}
